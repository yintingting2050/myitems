<?php
namespace Home\Controller;
use Think\Controller;

//联系我们
class ContactController extends Controller {
    public function index(){
        return $this->display();
    }

//    public function add(){
//        //判断室友有POST请求
//        if(IS_POST){
//            $admin =M('goods');
//            //判断是否超级管理员，内置验证1108,1表示超级管理员，0是默认表示非超级管理员
//            $data=array(
//                "first_type"=>$_POST['first_type'],
//                "second_type"=>$_POST['second_type'],
//                "time"=>date('Y-m-d H:i:s')
//            );
//            $result=$admin->add($data);
//            if($result){
//                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
//                $this->success('添加商品类型成功','lst',3);
//            } else {
//                //错误页面的默认跳转页面是返回前一页，通常不需要设置
//                $this->error('添加商品类型失败','lst',3);
//            }
//        }
//        $this->display();
//    }
//
//    public function edit(){
//        if(IS_POST) {
//            $goodstype =M('goods');
//            $data = array(
//                'id' => $_GET('id'),
//                'first_type' => $_POST('first_type'),
//                'second_type' => $_POST('second_type'),
//            );
//            $result=$goodstype->add($data);
//            if($result){
//                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
//                $this->success('修改商品类型成功','lst',3);
//            } else {
//                //错误页面的默认跳转页面是返回前一页，通常不需要设置
//                $this->error('修改商品类型失败','lst',3);
//            }
//        }
////        $id=$_GET('id');
////        $goodstype=M('goodstype')->where('id',$id)->find();
////        $this->assign('goodstype',$goodstype);
////        return $this->fetch() ;
//
//    }
//
//
//    public function del()
//    {
//
//        $goodstype=M('goods');
//        $id = $_GET['id'];
//        $result=$goodstype->where('id='.$id)->delete();
//        if ($result) {
//            return $this->success('删除类别成功!', 'lst');
//        } else {
//            return $this->error('删除类别失败！');
//        }
//    }
}