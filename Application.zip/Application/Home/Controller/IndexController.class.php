<?php
namespace Home\Controller;
use Think\Controller;

//前台主页
class IndexController extends Controller {
    public function index(){
      return $this->display();
    }
}