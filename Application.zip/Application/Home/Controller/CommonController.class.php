<?php
namespace Home\Controller;
use Think\Controller;

//公共模块，传递登录用户
class CommonController extends Controller {
    public function common()
    {
        if(!isset($_SESSION['username'])){
           $this->error("请登录！","login",2);
        }
        $userid=$_SESSION["userid"];
        $pwd=$_SESSION['password'];
//        echo $userid.$pwd;die;
        $this->assign("userid",$userid);
        $this->assign("password",$pwd);
    }
}