<?php
namespace Home\Controller;
use Think\Controller;
use Home\Controller\CommonController;

//订单显示，删除
class OrderController extends CommonController {

    public function lst(){
        $order =M('order');
        $data=$order->select();
        $this->assign('order',$data);
        $this->display();
    }
  //创建用户信息
    public function createorder()
    {
        $userinfo = M("order_userinfo");
        $data = array(
            "country" => $_POST['country'],
            "username" => $_POST['username'],
            "email" => $_POST['email'],
            "tel" => $_POST['tel'],
            "address" => $_POST['address'],
            "emailcode" => $_POST['emailcode']
        );
        $orderuser = $userinfo->add($data);
//        echo $orderuser;die;
        $cart=M('cart');
        $cartinfo=$cart->where('userid='.$_SESSION['userid'])->select();
//        print_r($cartinfo);die;
          $order=M("order");
            $data['ordernum']=date('Ymd');
            $data['goodsname']=$cartinfo['name'];
            $data['pic']=$cartinfo['pic'];
            $data['sum']=$cartinfo['sum'];
            $data['price']=$cartinfo['price'];
            $data['time']=mktime();
            $data['userid']=$_SESSION['userid'];
            $data['infoid']=$orderuser;


        $orderall=$order->add($data);

//        if ($result) {
//            echo "<script>alert('用户信息保存成功!')</script>";
////            $this->success('用户信息保存成功!');
//        } else {
//            echo "<script>alert('用户信息保存失败!')</script>";
////            $this->error('用户信息添加失败！');
//        }
    }

    public function add(){

    }

    public function edit(){

    }

    public function del()
    {

        $order=M('order');
        $id = $_GET['id'];
        $result= $order->where('id='.$id)->delete();
        if ($result) {
            $this->success('删除订单成功!', 'lst');
        } else {
            $this->error('删除订单失败！');
        }
    }
}