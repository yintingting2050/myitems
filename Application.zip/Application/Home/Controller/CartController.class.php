<?php
namespace Home\Controller;
use Think\Controller;
use Home\Controller\CommonController;
//购物车列表，添加,删除
class CartController extends CommonController{
    public function lst(){
        $cart=M('cart');
       $userid=$_SESSION['userid'];
       $data=$cart->where("userid=".$userid)->select();
//        $data= $cart->join('sp_goods on sp_cart.goodsid=sp_goods.id')->select();
//        print_r($data);die;
        $this->assign('cart',$data);
        return $this->display();
    }
    public function cart(){
        $cart=M('cart');
        $userid=$_SESSION['userid'];
        $data=$cart->where("userid=".$userid)->select();
        $this->assign('cart',$data);
        $user=M('user');
        $this->assign('user',$user);
//        var_dump($select2);
        return $this->display();
    }

//把商品列表要买商品的id获取加入购物车
    public function add()
    {
        $goods = M('goods');
        $id = $_GET['id'];//商品列表传过来的id
        $select = $goods->where('id='.$id)->find();
//        print_r($select);die;
        $cart = M('cart');
        if (isset($_GET['id'])) {
            $data = array(
                "name" => $select['goodsname'],
                "price" => $select['price'],
                "pic" => $select['pic'],
                "time" => mktime(),
                "userid" => $_SESSION['userid'],
                "goodsid" => $select['id']
            );
            $result = $cart->add($data);
            if ($result) {
                //设置成功后跳转页面的地址
                $this->success('添加购物车成功', 'cart', 2);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('添加购物车失败', U('shop/lst'), 2);
            }
        }
    }
    public function update(){
        $cart = M('cart');
        $userid=$_SESSION['userid'];
        $data['num']=$_POST["num"];
        $num=$data['num'];
//      print_r($data['num']);die;
        foreach ($num as $key=>$item){
               $data['num']=$item;
               $id=$_POST['cartid'][$key];
//               print_r($id);die;
            $result=$cart->where("userid='$userid'and id ='$id'")->save($data);
            if ($result) {
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('更新购物车成功', U('checkout/checkout'), 1);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('更新购物车失败', 'cart', 1);
            }
        }
//        $result=$cart->where('userid='.$userid .'and id ='.$id)->save($data);

    }

    //删除购物车中商品
    public function del()
    {
        $cart=M('cart');
        $id = $_GET['id'];
        $result=$cart->where('goodsid='.$id)->delete();
        if ($result) {
            $this->success('删除商品成功!', 'cart',1);
        } else {
          $this->error('删除商品失败！','cart',1);
        }
    }
}