<?php
namespace Home\Controller;
use Think\Controller;

//前台用户登录，注册模块，个人信息
class UserController extends Controller {
    //用户登录
    public  function login(){
        $this->display();

    }
    //检测登录
    public  function check(){
        $_SESSION['username']=I('post.username');
        $_SESSION['password']=I('post.password');
        $username=$_SESSION['username'];
        $password=$_SESSION['password'];
//        echo $username.$password;die;
        $user=M("user");	// 实例化类,参数数据表名称，不包含前缀
        $data= $user->where("username='$username' and password='$password'")->find();
//        print_r($data);die;
        $_SESSION["userid"]=$data['id'];
//        echo $_SESSION["userid"];die;
        if (isset($username)&&isset($password)){
            $select = $user->query("select * from sp_user where username='$username' and password='$password'");
//            print_r($select);die;
//            $select = $user->query("select * from sp_user where username='".$_POST['username']."' and password='".$_POST['password']."'");
            if ($select) {
                $this->success("用户登录成功！", U('Index/index'), 2);
            } else {
                $this->error('用户名或者密码不正确！', 'login', 2);
            }
        }
    }

    //用户注册
    public function register(){
        //判断是否有POST请求
        if(IS_POST){
            $user=M('user');
            $data=array(  //获取前端表单得到的值
                "username"=>$_POST['username'],
                "password"=>$_POST['password'],
                "email"=>$_POST['email'],
                "tel"=>$_POST['tel'],
                "address"=>$_POST['address'],
                "time"=>mktime()
            );
            $result=$user->add($data);
            if($result){
                //设置成功后跳转页面的地址
                $this->success('注册完成','login',3);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('注册失败','register',3);
            }
        }
            $this->display();
    }

    //用户中心，个人信息
    public function profile(){
        $user =M('user');
        $select=$user->select();
        $this->assign("select",$select);
        $this->display();

    }

}