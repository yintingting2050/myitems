<?php
namespace Home\Controller;
use Think\Controller;
use Home\Controller\CommonController;
class CheckoutController extends CommonController
{
    public function checkout()
    {
        $cart=M("cart");
        $select=$cart->where('userid='.$_SESSION['userid'])->select();
        $this->assign('cart',$select);
        $this->display();
    }



}