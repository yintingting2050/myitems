<?php
namespace Home\Model;
use Think\Model;
class AdminModel extends Model{

}