<?php
namespace Home\Model;
use Think\Model;
class UserModel extends Model{
    //假如你的表名与模型名不一致，需要显示指定表名
    protected  $table='user';
}