<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>资料展示页面</title>
<link rel="stylesheet" href="/Shopdemo/Public/static/admin/css/style.default.css" type="text/css" />
<script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery-1.7.min.js"></script>
<script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery.cookie.js"></script>
<script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery.bxSlider.min.js"></script>
<script type="text/javascript" src="/Shopdemo/Public/static/admin/js/custom/general.js"></script>
<script type="text/javascript" src="/Shopdemo/Public/static/admin/js/custom/profile.js"></script>
<!--[if IE 9]>
    <link rel="stylesheet" media="screen" href="/Shopdemo/Public/static/admin/css/style.ie9.css"/>
<![endif]-->
<!--[if IE 8]>
    <link rel="stylesheet" media="screen" href="/Shopdemo/Public/static/admin/css/style.ie8.css"/>
<![endif]-->
<!--[if lt IE 9]>
	<script src="/Shopdemo/Public/static/admin/js/plugins/css3-mediaqueries.js"></script>
<![endif]-->
</head>

<body class="withvernav">
<div class="bodywrapper">
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="topheader">
    <div class="left">
        <h1 class="logo"><span>个人中心</span></h1>
        <span ><a href="<?php echo U('Home/Index/index');?>" style="color: yellow">商城首页</a></span>



        <!--<div class="search">-->
            <!--<form action="" method="post">-->
                <!--<input type="text" name="keyword" id="keyword" value="" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">-->
                <!--<button class="submitbutton"></button>-->
            <!--</form>-->
        <!--</div>&lt;!&ndash;search&ndash;&gt;-->

        <br clear="all">

    </div><!--left-->

    <div class="right">
        <div class="notification">
            <a class="count" href="notifications.html"><span>9</span></a>
        </div>


        <div class="userinfo">
            <img src="/Shopdemo/Public/static/admin/images/thumbs/avatar.png" alt="">
            <span>殷婷婷</span>
        </div><!--userinfo-->

        <div class="userinfodrop">
            <div class="avatar">
                <a href="">
                    <img src="/Shopdemo/Public/static/admin/images/thumbs/avatarbig.png" alt=""></a>
                <div class="changetheme">修改主题: <br>
                    <a class="default"></a>
                    <a class="blueline"></a>
                    <a class="greenline"></a>
                    <a class="contrast"></a>
                    <a class="custombg"></a>
                </div>
            </div><!--avatar-->
            <div class="userdata">
                <h4>殷婷婷</h4>
                <span class="email">youremail@yourdomain.com</span>
                <ul>
                    <li><a href="editprofile.html">编辑信息</a></li>
                    <li><a href="accountsettings.html">账户设置</a></li>
                    <li><a href="help.html">帮助</a></li>
                    <!--<li><a href="../../../../../../../../../Users/lanou3g/Desktop/PHP_Template/backOffice%20for%20shop/index.html">Sign Out</a></li>-->
                </ul>
            </div><!--userdata-->
        </div><!--userinfodrop-->
    </div><!--right-->
</div>
</body>
</html>

    <div class="header">
        welcome!
    </div><!--header-->

    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="vernav2 iconmenu">
    <ul>
        <li><a href="#formsub" class="editor">我的订单</a>
            <span class="arrow"></span>
            <ul id="formsub">
                <li><a href="<?php echo U('Home/Order/lst');?>">全部订单</a></li>
                <li><a href="">待付款</a></li>
                <li><a href="">待发货</a></li>
                <li><a href="">待收货</a></li>
                <li><a href="">待评价</a></li>
            </ul>
        </li>
        <!--<li><a href="filemanager.html" class="gallery">File Manager</a></li>-->
        <li><a href="<?php echo U('Home/Cart/lst');?>" class="elements">购物车</a></li>
        <li><a href="" class="widgets">收藏夹</a></li>
        <li><a href="" class="calendar">我的收货地址</a></li>
        <li><a href="" class="support">卡券包</a></li>

</body>
</html>


    </div><!--leftmenu-->
        
    <div class="centercontent">
    
        <div class="pageheader">
        	<span class="profilepic"><img src="/Shopdemo/Public/static/admin/images/thumbs/avatarbig.png" alt="" /></span>
            <div class="profiletitle">
            <h1 class="pagetitle">殷婷婷</h1>
            <!--<span class="pagedesc">Front-End Engineer / UI Designer</span>-->
                <br />
            </div>
            <ul class="hornav">
                <li class="current"><a href="#profile">我的信息</a></li>
                <li><a href="#editprofile">编辑信息</a></li>
            </ul>
        </div><!--pageheader-->
        
        <div id="contentwrapper" class="contentwrapper">
        
        	<div class="two_third last profile_wrapper">
                <div id="profile" class="subcontent">
                    <!--<button id="followbtn" class="stdbtn btn_yellow followbtn">Follow</button>-->
                    <!--<ul class="profile_summary">-->
                        <!--<li><a href="followers.html"><span>15</span> Followers</a></li>-->
                        <!--<li><a href="" id="following"><span>20</span> Following</a></li>-->
                        <!--<li><a href="blog.html"><span>2</span> Blog</a></li>-->
                        <!--<li><a href=""><span>8</span> Project Shots</a></li>-->
                    <!--</ul>-->
                    
                    
                    <!--<blockquote class="bq2 currentstatus marginbottom0">-->
                        <!--<a class="edit_status" title="Edit Status"></a>-->
                        <!--This is an example of my current status. When clicking Follow button above, watch how the number of Following change. This is ajax implementation ready, just read the documentation on how. :)-->
                    <!--</blockquote>-->
                    
                    
                    <div class="contenttitle2">
                        <h3>关于我</h3>
                    </div><!--contenttitle-->
                    
                    <div class="profile_about" >
                        <div>
                            <span >我的昵称：</span>
                            <input type="text" name="username" value="" />
                        </div>
                        <div >
                            <span >性别：</span>
                            <input type="radio" name="text" value="男" />男
                            <input type="radio" name="text" value="女" />女
                        </div>
                        <div>
                            <span >邮箱：</span><input type="text" name="email" value=""/>
                        </div>
                        <div>
                            <span >电话：</span><input type="text" name="tel"  value=""/>
                        </div>
                    </div>
                    
                    
                    <div class="contenttitle2">
                        <h3>近期浏览</h3>
                    </div><!--contenttitle-->
                    
                    <div class="recentblog">
                        <div class="blogthumb">
                            <a href="blogview.html">
                                <img src="/Shopdemo/Public/static/admin/images/preview/blog1.png" alt="" /></a>
                        </div><!--blogthumb-->
                        <div class="blogsummary">
                            <h3><a href="blogview.html">Some Tutorials (an in-house blog)</a></h3>
                            <small>June 10, 2012 3:30pm &nbsp;/&nbsp; 0 Comment</small>
                            <p>This is where you can discuss or give some tips/tutorials as a guide for your fellow teammates. Vivamus vitae lacus dui, in vestibulum augue. Vestibulum ante ipsum primis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut eget nibh urna. Vivamus vitae lacus dui.</p>
                            <p><a href="blogview.html" class="orangeboldlink">Read More &raquo;</a></p>
                        </div><!--blogsummary-->
                    </div><!--recentblog-->
                    
                    <br clear="all" />
                    
                    <div class="contenttitle2">
                        <h3>Project Shots</h3>
                    </div><!--contenttitle-->
                    
                    <ul class="recentshots">
                        <li>
                            <a href="" class="th"><img src="/Shopdemo/Public/static/admin/images/preview/portfolio1.png" alt="" /></a>
                            <h4><a href="">Admin Template</a></h4>
                            <small>2 Comments</small>
                        </li>
                        <li>
                            <a href="" class="th"><img src="/Shopdemo/Public/static/admin/images/preview/portfolio2.png" alt="" /></a>
                            <h4><a href="">File Manager</a></h4>
                            <small>0 Comment</small>
                        </li>
                     </ul>
    
                    
                    <br clear="all" />
                    
                </div><!--#profile-->
                
                <div id="editprofile" class="subcontent" style="display: none">
                    Edit profile form goes here...
                </div><!--#editprofile-->
                
                <br /><br />
            </div><!--two_third-->
            
            <br /><br />
            
        </div><!--contentwrapper-->
                
	</div><!-- centercontent -->
    
    
</div><!--bodywrapper-->

</body>
</html>