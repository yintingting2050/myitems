<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>资料展示页面</title>
    <link rel="stylesheet" href="/Shopdemo/Public/static/admin/css/style.default.css" type="text/css" />
    <script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery-1.7.min.js"></script>
    <script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery-ui-1.8.16.custom.min.js"></script>
    <script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery.cookie.js"></script>
    <script type="text/javascript" src="/Shopdemo/Public/static/admin/js/plugins/jquery.bxSlider.min.js"></script>
    <script type="text/javascript" src="/Shopdemo/Public/static/admin/js/custom/general.js"></script>
    <script type="text/javascript" src="/Shopdemo/Public/static/admin/js/custom/profile.js"></script>
    <link rel="stylesheet" type="text/css" href="/Shopdemo/Public/static/admin/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="/Shopdemo/Public/static/admin/css/main.css"/>
    <script type="text/javascript" src="/Shopdemo/Public/static/admin/js/libs/modernizr.min.js"></script>
    <!--[if IE 9]>
    <link rel="stylesheet" media="screen" href="/Shopdemo/Public/static/admin/css/style.ie9.css"/>
    <![endif]-->
    <!--[if IE 8]>
    <link rel="stylesheet" media="screen" href="/Shopdemo/Public/static/admin/css/style.ie8.css"/>
    <![endif]-->
    <!--[if lt IE 9]>
    <script src="/Shopdemo/Public/static/admin/js/plugins/css3-mediaqueries.js"></script>
    <![endif]-->
</head>

<body class="withvernav">
<div class="bodywrapper">
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="topheader">
    <div class="left">
        <h1 class="logo"><span>个人中心</span></h1>
        <span ><a href="<?php echo U('Home/Index/index');?>" style="color: yellow">商城首页</a></span>



        <!--<div class="search">-->
            <!--<form action="" method="post">-->
                <!--<input type="text" name="keyword" id="keyword" value="" class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">-->
                <!--<button class="submitbutton"></button>-->
            <!--</form>-->
        <!--</div>&lt;!&ndash;search&ndash;&gt;-->

        <br clear="all">

    </div><!--left-->

    <div class="right">
        <div class="notification">
            <a class="count" href="notifications.html"><span>9</span></a>
        </div>


        <div class="userinfo">
            <img src="/Shopdemo/Public/static/admin/images/thumbs/avatar.png" alt="">
            <span>殷婷婷</span>
        </div><!--userinfo-->

        <div class="userinfodrop">
            <div class="avatar">
                <a href="">
                    <img src="/Shopdemo/Public/static/admin/images/thumbs/avatarbig.png" alt=""></a>
                <div class="changetheme">修改主题: <br>
                    <a class="default"></a>
                    <a class="blueline"></a>
                    <a class="greenline"></a>
                    <a class="contrast"></a>
                    <a class="custombg"></a>
                </div>
            </div><!--avatar-->
            <div class="userdata">
                <h4>殷婷婷</h4>
                <span class="email">youremail@yourdomain.com</span>
                <ul>
                    <li><a href="editprofile.html">编辑信息</a></li>
                    <li><a href="accountsettings.html">账户设置</a></li>
                    <li><a href="help.html">帮助</a></li>
                    <!--<li><a href="../../../../../../../../../Users/lanou3g/Desktop/PHP_Template/backOffice%20for%20shop/index.html">Sign Out</a></li>-->
                </ul>
            </div><!--userdata-->
        </div><!--userinfodrop-->
    </div><!--right-->
</div>
</body>
</html>

    <div class="header">
        welcome!
    </div><!--header-->
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div class="vernav2 iconmenu">
    <ul>
        <li><a href="#formsub" class="editor">我的订单</a>
            <span class="arrow"></span>
            <ul id="formsub">
                <li><a href="<?php echo U('Home/Order/lst');?>">全部订单</a></li>
                <li><a href="">待付款</a></li>
                <li><a href="">待发货</a></li>
                <li><a href="">待收货</a></li>
                <li><a href="">待评价</a></li>
            </ul>
        </li>
        <!--<li><a href="filemanager.html" class="gallery">File Manager</a></li>-->
        <li><a href="<?php echo U('Home/Cart/lst');?>" class="elements">购物车</a></li>
        <li><a href="" class="widgets">收藏夹</a></li>
        <li><a href="" class="calendar">我的收货地址</a></li>
        <li><a href="" class="support">卡券包</a></li>

</body>
</html>

</div><!--leftmenu-->

<div class="centercontent">

    <div class="pageheader">
            <h1 class="pagetitle">我的全部订单</h1>
        <form name="myform" id="myform" method="post">

            <div class="result-content">
                <table class="result-tab" width="100%">
                    <tr>
                        <th width="3%">ID</th>
                        <th>缩略图</th>
                        <th>商品名称</th>
                        <th>数量</th>
                        <th>价格</th>
                        <th>运费</th>
                        <th>操作</th>
                    </tr>
                    <?php if(is_array($order)): $i = 0; $__LIST__ = $order;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                        <td width="3%"><?php echo ($vo["id"]); ?></td>
                        <td>
                            <?php if($vo['pic'] != ''): ?><img height="50" src="">
                            <?php else: ?>
                            暂无缩略图<?php endif; ?>
                        </td>
                        <td><?php echo ($vo["ordername"]); ?></td>
                        <td><?php echo ($vo["sum"]); ?></td>
                        <td><?php echo ($vo["price"]); ?></td>
                        <td><?php echo (date("Y-m-d",$vo["time"])); ?></td>
                        <td>
                            <a class="link-update" href="">修改</a>
                            <a class="link-del" onclick="return confirm('你确定要删除吗？');" href="">删除</a>
                        </td>
                    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                </table>

                <div class="list-page"></div>
            </div>
        </form>
    </div>


    </div><!--pageheader-->













</body>
</html>