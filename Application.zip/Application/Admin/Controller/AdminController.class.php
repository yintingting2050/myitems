<?php
namespace Admin\Controller;
use Think\Controller;
//定义后台管理员控制器
class AdminController extends Controller {
    //管理员登录页面，判断是超级管理员还是普通管理员
    public  function login(){
        if(isset($_POST['adminname'])) {
            $db = M('admin');// 实例化模型类,参数数据表名称，不包含前缀
            $select = $db->query("select * from sp_admin where username='" . $_POST['adminname'] . "' and password='" . $_POST['password'] . "'");
            if ($_POST['adminname'] == 'ytt' && $_POST['password'] = '666') {
                $_SESSION['admin'] = $_POST['adminname'];
                $this->success('超级管理员' . 'ytt' . '登录成功！', 'lst', 2);
            } else if ($select) {
                $_SESSION['admin'] = $_POST['adminname'];
                $this->success('普通管理员' . $_POST['adminname'] . '登录成功！', 'lst', 2);
            } else {
                $this->error($_POST['adminname'] . '您不是管理员', 'login', 2);
            }
        }
        $this->display();
    }
    //显示所有管理员
    public function lst(){ //定义显示视图方法
        $admin =M('admin');//实例化模型类 参数为admin 数据表
        $data=$admin->select();//执行查询方法
        $this->assign('data',$data);//分配至模板
        $this->display();//发送到当前视图函数
    }

    //添加管理员（超级管理员才能操作）
    public function add(){

        $_SESSION['username']="ytt";
        $_SESSION['password']="666";
//        $data=$admin->select();
        if($_SESSION['adminname']=='ytt'&&$_SESSION['password']=="666") {
//        $super=$_POST['super']==1108?'1':'0';
            $admin = M('admin');
            $data = array(  //获取前端表单得到的值
                "username" => $_POST['adminname'],
                "password" => $_POST['password'],
                "super" => 0,
                "time"=>mktime()
            );
            $result = $admin->add($data);
            if ($result) {
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('添加管理员完成', 'lst', 3);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('添加管理员失败', 'lst', 3);
            }
        }else{
            $this->error('您没有权限添加管理员','lst',3);
        }
            $this->display();
    }
    //编辑管理员信息（超级管理员才能操作）
    public function edit(){
        $admin =M('admin');
        $id = $_GET['id'];
        $select=$admin->where('id='.$id)->select();
        $this->assign('select',$select);
        $this->display();
        $super=$_POST['super']==1108?'1':'0';
        if(isset($_POST['id'])) {
            $data = array(
                "username"=>$_POST['username'],
                "password"=>$_POST['password'],
                "super"=>$super,
                "time"=>mktime()
            );
            $result=$admin->where('id='.$_POST['id'])->save($data);

            if($result){
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('修改管理员成功','lst',2);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('修改管理员失败','lst',2);
            }
        }
    }
//删除管理员信息（超级管理员才能操作）
    public function del(){
        $goodstype=M('admin');
        $id = $_GET['id'];
        $result=$goodstype->where('id='.$id)->delete();
        if ($result) {
            $this->success('删除管理员成功!', 'lst');
        } else {
            $this->error('删除管理员失败！');
        }
    }

}