<?php
namespace Admin\Controller;
use Think\Controller;
//链接模块，删除，添加
class LinkController extends Controller {
    public function lst(){
        $link =M('link');
        $data=$link->select();
        $this->assign('links',$data);
        $this->display();
    }
    public function add(){
        //判断有POST请求
        if(IS_POST){
            $link =M('link');
            $data=array(
                "title"=>$_POST['title'],
                "url"=>$_POST['url'],
                "desc"=>$_POST['desc'],
                "time"=>mktime()
            );
            $result=$link->add($data);
            if($result){
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('添加链接成功','lst',2);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('添加链接失败','lst',2);
            }
        }
        $this->display();
    }
    public function del()
    {
        $link=M('link');
        $id = $_GET['id'];
        $result=$link->where('id='.$id)->delete();
        if ($result) {
            $this->success('删除链接成功!', 'lst',2);
        } else {
            $this->error('删除链接失败！','lst',2);
        }
    }
}