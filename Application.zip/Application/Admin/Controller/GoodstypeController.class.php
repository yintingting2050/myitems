<?php
namespace Admin\Controller;
use Think\Controller;

//商品类型模块
class GoodstypeController extends Controller {
//商品类型显示
    public function lst(){
        $goodstype =M('goodstype');
        $data=$goodstype->select();
        $this->assign('type',$data);
        $this->display();
    }

///添加商品类型
    public function add(){
        //判断有POST请求
        if(IS_POST){
            $goodstype =M('goodstype');
            $data=array(
                "first_type"=>$_POST['first_type'],
                "second_type"=>$_POST['second_type'],
                "time"=>mktime()//时间戳
            );
            $result=$goodstype->add($data);
            if($result){
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('添加商品类型成功','lst',3);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('添加商品类型失败','lst',3);
            }
        }
        $this->display();
    }
///编辑商品类型
    public function edit(){
        $goodstype =M('goodstype');
        $id = $_GET['id'];
        $select=$goodstype->where('id='.$id)->select();
        $this->assign('select',$select);
        $this->display();
        if(isset($_POST['id'])) {
            $data = array(
                'first_type' => $_POST['first_type'],
                'second_type' => $_POST['second_type'],
                'time' =>mktime()
            );
            $result=$goodstype->where('id='.$_POST['id'])->save($data);

            if($result){
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('修改商品类型成功','lst',2);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('修改商品类型失败','lst',2);
            }
        }

    }
///删除商品类型
    public function del()
    {
        $goodstype=M('goodstype');
        $id = $_GET['id'];
        $result=$goodstype->where('id='.$id)->delete();
        if ($result) {
             $this->success('删除类别成功!', 'lst');
        } else {
           $this->error('删除类别失败！');
        }
    }
}