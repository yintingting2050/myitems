<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Upload;

//后台商品操作模块
class GoodsController extends Controller {
//商品显示
    public function lst(){
        $admin =M('goods');
        $data=$admin->select();
        $this->assign('goods',$data);
        $this->display();
    }
//商品添加
    public function add(){
        //判断室友有POST请求
        if(IS_POST){
            $goods =M('goods');

            //商品头像上传
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =     './public/static/uploads/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            // 上传文件
            $info = $upload->upload();
            if(!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            }else{// 上传成功
               // $this->success('上传成功！');
            }
            //添加商品信息到goods表
            $data=array(
                "goodsname"=>$_POST['goodsname'],
                "sum"=>$_POST['sum'],
                "price"=>$_POST['price'],
                "typeid"=>$_POST['typeid'],
                "desc"=>$_POST['desc'],
                "pic"=>'/static/uploads/'.date('Y-m-d').'/'.$info['pic']['savename'],
                "time"=>mktime()
            );
//            $data['pic'] = '/static/uploads/' . date('Ymd').'/'. $info->getFilename();
//            echo "<img src=$path>";
            $result=$goods->add($data);
            if($result){
               // echo $result['typeid'];die;
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('添加商品成功','lst',2);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('添加商品失败','lst',2);
            }
        }
        $this->display();
    }

    //后台商品编辑
    public function edit(){
        $goods =M('goods');
        $id = $_GET['id'];
        $select=$goods->where('id='.$id)->select();
        $goodstype = M('goodstype')->select();
        $this->assign('goodstype', $goodstype);
        $this->assign('select',$select);
        $this->display();

        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->rootPath  =     './public/static/uploads/'; // 设置附件上传根目录
        $upload->savePath  =     ''; // 设置附件上传（子）目录
        // 上传文件
        $info = $upload->upload();
        if(isset($_POST['id'])) {
            $data = array(
                "goodsname"=>$_POST['goodsname'],
                "sum"=>$_POST['sum'],
                "price"=>$_POST['price'],
                "typeid"=>$_POST['typeid'],
                "desc"=>$_POST['desc'],
                "pic"=>'/static/uploads/'.date('Y-m-d').'/'.$info['pic']['savename'],
                "time"=>mktime()
            );
            $result=$goods->where('id='.$_POST['id'])->save($data);

            if($result){
                //设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERER']
                $this->success('修改商品类型成功','lst',2);
            } else {
                //错误页面的默认跳转页面是返回前一页，通常不需要设置
                $this->error('修改商品类型失败','lst',2);
            }
        }
    }
//后台商品删除
    public function del()
    {

        $goods=M('goods');
        $id = $_GET['id'];
        $result=$goods->where('id='.$id)->delete();
        if ($result) {
            $this->success('删除商品成功!', 'lst');
        } else {
            $this->error('删除商品失败！');
        }
    }
}