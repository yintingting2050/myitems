<?php
namespace Admin\Controller;
use Think\Controller;

//后台主页
class IndexController extends Controller {
    public function index(){
      return $this->display();
    }
}