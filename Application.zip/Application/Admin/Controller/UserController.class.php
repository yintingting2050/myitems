<?php
namespace Admin\Controller;
use Home\Model\UserModel;
use Think\Controller;
use Think\Model;

//后台用户管理控制器
class UserController extends Controller {
    //查
    public function lst(){
  $data = M('user');
  $user = $data ->select();
//        $data = new UserModel();
//        $user=$data->sel();
        $this->assign('user',$user);
         $this->display();
    }

    //删
    public function del(){
        $id = $_GET['id'];
        $data = new Model('user');
        $del=$data->where("id=$id")->delete();
        if($del){
            $this->success('删除成功！','lst');
        }else{
            $this->error('删除失败！');
        }
    }

    //增 添加用户方法
    public function add(){
        date_default_timezone_set("PRC");
        if(IS_POST){//判断是否是表单提交 获取表单输入值 IS_POST
            $data['username']=$_POST['username'];
            $data['password']=$_POST['password'];
            $data['email']=$_POST['email'];
            $data['tel']=$_POST['tel'];
            $data['time']=mktime();//获取时间
            $data['ip']=get_client_ip();//获取IP
            $user= M('User');//实例化模型类
            $res=$user->add($data);//执行添加操作
            if($res){
                //成功时 返回提示信息 并进行页面跳转
                $this->success('用户信息添加成功','lst');
            }else{
                $this->error('用户信息添加失败');
            }
        }
            $this->display();
    }

    //改
    public function edit(){
        //访问路径 如 http://localhost/Shopdemo/index.php/Home/User/edit?id=5
        date_default_timezone_set("PRC");//设置本地时区
       $id=$_GET['id'];//首先获取 需要修改的记录id
       $user=new Model('User');
        $edits=$user->where('id='.$_GET['id'])->select();
//        echo $id;
//        print_r($edits);
         $this->assign('edits',$edits);
        $this->display('edit');

         if(isset($_POST['id'])){//判断是否是表单提交 获取表单输入值
               $data['username']=$_POST['username'];
               $data['password']=$_POST['password'];
               $data['email']=$_POST['email'];
               $data['tel']=$_POST['tel'];
               $data['time']=mktime();//获取时间
               $data['ip']=get_client_ip();//获取IP
               $res=$user->where('id='.$id)->save($data);//执行添加操作
               if($res){
                   //成功时 返回提示信息 并进行页面跳转
                   $this->success('用户信息更新成功','lst',3);
               }else{
                   $this->error('用户信息更新失败');
               }
           }
    }
}