<?php
namespace Admin\Model;
use Think\Model;
class AdminModel extends Model{

}