<?php
namespace Admin\Model;
use Think\Model;
class GoodsModel extends Model{


}