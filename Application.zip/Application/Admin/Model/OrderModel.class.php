<?php
namespace Admin\Model;
use Think\Model\RelationModel;
class OrderModel extends RelationModel{
    //假如你的表名与模型名不一致，需要显示指定表名
//    protected  $table='order';
    //关联模型设定
    //通过$_link的数组来定义
    //数组的每一项定义了一种关联
    protected $_link=array(
        'user'=>array(
            'mapping_type'=> self::BELONGS_TO,
            'class_name'=>'user',
            'foreign_key'=>'userid',

        ),

    );
}